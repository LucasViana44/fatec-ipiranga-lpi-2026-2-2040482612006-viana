import java.io.*;
import java.util.Scanner;

// Tema 2 - Sistema de Gestão Acadêmica (Instituto Qualifica Mais)
public class SistemaAcademico {

    static final int MAX_ESTUDANTES = 40, MAX_DISCIPLINAS = 6;
    static final int RA_MINIMO = 10000, RA_MAXIMO = 99999;
    static final int CODIGO_MINIMO = 100, CODIGO_MAXIMO = 999;
    static final int CARGA_MINIMA = 20, CARGA_MAXIMA = 200;
    static final int MATRICULADO = 1, TRANCADO = 2;
    static final double MEDIA_MINIMA = 6.0, FREQUENCIA_MINIMA = 75.0, NAO_LANCADA = -1.0;
    static final String[] NOMES_SITUACAO = {"Matriculado", "Trancado"};
    static final String ARQ_DISCIPLINAS = "disciplinas.txt", ARQ_ESTUDANTES = "estudantes.txt", ARQ_DESEMPENHO = "desempenho.txt";

    static Scanner sc = new Scanner(System.in);

    // arrays paralelos de estudantes (posição i) e de disciplinas (posição j)
    static int[] ras = new int[MAX_ESTUDANTES];
    static String[] nomes = new String[MAX_ESTUDANTES];
    static int[] situacoes = new int[MAX_ESTUDANTES];
    static int qtdEstudantes = 0;
    static int[] codigos = new int[MAX_DISCIPLINAS];
    static String[] nomesDisciplinas = new String[MAX_DISCIPLINAS];
    static int[] cargas = new int[MAX_DISCIPLINAS];
    static int qtdDisciplinas = 0;

    // matrizes: linha i = estudante, coluna j = disciplina
    static double[][] notasP1 = new double[MAX_ESTUDANTES][MAX_DISCIPLINAS];
    static double[][] notasP2 = new double[MAX_ESTUDANTES][MAX_DISCIPLINAS];
    static int[][] faltas = new int[MAX_ESTUDANTES][MAX_DISCIPLINAS];

    public static void main(String[] args) {
        int opcao;
        carregarDados();
        do {
            exibirMenu();
            opcao = lerOpcao();
            switch (opcao) {
                case 1: cadastrarDisciplina(); break;
                case 2: listarDisciplinas(); break;
                case 3: cadastrarEstudante(); break;
                case 4: alterarNomeEstudante(); break;
                case 5: alterarMatricula(); break;
                case 6: listarEstudantes(); break;
                case 7: consultarEstudante(); break;
                case 8: lancarNotas(); break;
                case 9: lancarFaltas(); break;
                case 10: emitirBoletim(); break;
                case 11: relatorioPorDisciplina(); break;
                case 12: relatorioMediaGeral(); break;
                case 13: relatorioRisco(); break;
                case 14: exportarBoletim(); break;
                case 0: salvarDados(); System.out.println("Dados gravados. Até a próxima!"); break;
                default: System.out.println("Opção inválida.");
            }
            if (opcao != 0) { pausar(); }
        } while (opcao != 0);
    }

    // ---------- entrada de dados (nextLine + parse dentro do try: VG02) ----------

    static int lerInteiro(String msg, int min, int max) {
        while (true) {
            System.out.print(msg);
            try {
                int n = Integer.parseInt(sc.nextLine().trim());
                if (n >= min && n <= max) { return n; }
                System.out.println("Valor inválido. Digite um inteiro de " + min + " a " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Digite apenas números inteiros.");
            }
        }
    }

    static int lerOpcao() {
        System.out.print("Escolha uma opção: ");
        try {
            return Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1; // cai no "Opção inválida" do switch (VG08)
        }
    }

    static double lerDecimal(String msg, double min, double max) {
        while (true) {
            System.out.print(msg);
            try {
                double n = Double.parseDouble(sc.nextLine().trim().replace(",", "."));
                if (n >= min && n <= max) { return n; }
                System.out.println("Valor inválido. Digite um número de " + min + " a " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Digite um número (exemplo: 7,5).");
            }
        }
    }

    // VG01 e VG10: texto obrigatório e sem ";" (o ; separa os campos dos arquivos)
    static String lerTexto(String msg) {
        while (true) {
            System.out.print(msg);
            String t = sc.nextLine().trim();
            if (t.isEmpty()) { System.out.println("Campo obrigatório."); }
            else if (t.contains(";")) { System.out.println("O caractere ';' não é permitido."); }
            else { return t; }
        }
    }

    // RN02 e RN04: nome obrigatório; não permite números no nome.
    static boolean nomeValido(String nome) {
        if (nome == null || nome.trim().isEmpty()) { return false; }
        for (int i = 0; i < nome.length(); i++) {
            if (Character.isDigit(nome.charAt(i))) { return false; }
        }
        return true;
    }

    static String lerNome(String msg) {
        while (true) {
            String nome = lerTexto(msg);
            if (nomeValido(nome)) { return nome; }
            System.out.println("O nome não pode conter números.");
        }
    }

    static String nomeSituacao(int situacao) {
        return situacao == MATRICULADO ? "Matriculado" : "Trancado";
    }

    static boolean nomeEstudanteExiste(String nome, int indiceIgnorado) {
        for (int i = 0; i < qtdEstudantes; i++) {
            if (i != indiceIgnorado && nomes[i].equalsIgnoreCase(nome.trim())) { return true; }
        }
        return false;
    }

    static boolean confirmar(String msg) {
        while (true) {
            System.out.print(msg + " (S/N)? ");
            String r = sc.nextLine().trim();
            if (r.equalsIgnoreCase("S")) { return true; }
            if (r.equalsIgnoreCase("N")) { return false; }
            System.out.println("Responda S ou N.");
        }
    }

    static void pausar() {
        System.out.print("\nPressione ENTER para continuar...");
        sc.nextLine();
    }

    static void exibirMenu() {
        System.out.println("\n============== INSTITUTO QUALIFICA MAIS - GESTÃO ACADÊMICA ==============");
        System.out.println("CADASTROS     1 - Cadastrar disciplina");
        System.out.println("              2 - Listar disciplinas");
        System.out.println("              3 - Cadastrar estudante");
        System.out.println("              4 - Alterar nome do estudante");
        System.out.println("              5 - Trancar ou reativar matrícula");
        System.out.println("              6 - Listar estudantes");
        System.out.println("              7 - Consultar estudante por RA");
        System.out.println("LANÇAMENTOS   8 - Lançar notas (P1 e P2)");
        System.out.println("              9 - Lançar faltas");
        System.out.println("RELATÓRIOS   10 - Boletim do estudante");
        System.out.println("             11 - Desempenho da turma por disciplina");
        System.out.println("             12 - Média geral por estudante");
        System.out.println("             13 - Estudantes em situação de risco");
        System.out.println("ARQUIVOS     14 - Exportar boletim do estudante (arquivo)");
        System.out.println("              0 - Sair");
        System.out.println("=========================================================================");
    }

    // ---------- buscas e cálculos ----------

    static int buscarIndiceEstudante(int ra) {
        for (int i = 0; i < qtdEstudantes; i++) {
            if (ras[i] == ra) { return i; }
        }
        return -1;
    }

    static int buscarIndiceDisciplina(int codigo) {
        for (int j = 0; j < qtdDisciplinas; j++) {
            if (codigos[j] == codigo) { return j; }
        }
        return -1;
    }

    // pede o RA e devolve o índice do estudante, ou -1 avisando (VG06)
    static int pedirEstudante() {
        int i = buscarIndiceEstudante(lerInteiro("RA (10000 a 99999): ", RA_MINIMO, RA_MAXIMO));
        if (i == -1) { System.out.println("Estudante não encontrado."); }
        return i;
    }

    static int pedirDisciplina() {
        int j = buscarIndiceDisciplina(lerInteiro("Código da disciplina (100 a 999): ", CODIGO_MINIMO, CODIGO_MAXIMO));
        if (j == -1) { System.out.println("Disciplina não encontrada."); }
        return j;
    }

    // RN09: lançamento exige disciplina cadastrada e estudante matriculado
    static int pedirEstudanteParaLancamento() {
        if (qtdDisciplinas == 0) {
            System.out.println("ERRO: cadastre uma disciplina antes de fazer lançamentos.");
            return -1;
        }
        int i = pedirEstudante();
        if (i != -1 && situacoes[i] != MATRICULADO) {
            System.out.println("ERRO: a matrícula deste estudante está TRANCADA. Lançamento não permitido.");
            return -1;
        }
        return i;
    }

    // RN06: nota -1 (não lançada) e 0 faltas em todas as colunas
    static void inicializarDesempenho(int i) {
        for (int j = 0; j < MAX_DISCIPLINAS; j++) {
            notasP1[i][j] = NAO_LANCADA;
            notasP2[i][j] = NAO_LANCADA;
            faltas[i][j] = 0;
        }
    }

    // RN10: só existe média com as duas notas lançadas
    static double calcularMedia(int i, int j) {
        if (notasP1[i][j] < 0 || notasP2[i][j] < 0) { return NAO_LANCADA; }
        return (notasP1[i][j] + notasP2[i][j]) / 2;
    }

    // RN11
    static double calcularFrequencia(int i, int j) {
        return (cargas[j] - faltas[i][j]) * 100.0 / cargas[j];
    }

    // RN12
    static String situacaoDisciplina(int i, int j) {
        double media = calcularMedia(i, j);
        if (media < 0) { return "PENDENTE"; }
        boolean notaOk = media >= MEDIA_MINIMA;
        boolean freqOk = calcularFrequencia(i, j) >= FREQUENCIA_MINIMA;
        if (notaOk && freqOk) { return "APROVADO"; }
        if (freqOk) { return "REPROVADO POR NOTA"; }
        if (notaOk) { return "REPROVADO POR FALTA"; }
        return "REPROVADO POR NOTA E FALTA";
    }

    // RN15: média das médias das disciplinas com as duas notas (-1 = sem notas)
    static double calcularMediaGeral(int i) {
        double soma = 0;
        int qtd = 0;
        for (int j = 0; j < qtdDisciplinas; j++) {
            if (calcularMedia(i, j) >= 0) {
                soma += calcularMedia(i, j);
                qtd++;
            }
        }
        if (qtd == 0) { return NAO_LANCADA; }
        return soma / qtd;
    }

    // número como texto com 2 casas; valor negativo (não lançado) vira "--"
    static String texto(double valor) {
        if (valor < 0) { return "--"; }
        return String.format("%.2f", valor);
    }

    // ---------- requisitos funcionais ----------

    // RF01 (RN03, RN04, RN05, RN14; VG04)
    static void cadastrarDisciplina() {
        System.out.println("--- CADASTRAR DISCIPLINA ---");
        if (qtdDisciplinas >= MAX_DISCIPLINAS) {
            System.out.println("ERRO: limite de " + MAX_DISCIPLINAS + " disciplinas atingido.");
            return;
        }
        int codigo = lerInteiro("Código (100 a 999): ", CODIGO_MINIMO, CODIGO_MAXIMO);
        if (buscarIndiceDisciplina(codigo) != -1) {
            System.out.println("ERRO: já existe uma disciplina com o código " + codigo + ".");
            return;
        }
        codigos[qtdDisciplinas] = codigo;
        nomesDisciplinas[qtdDisciplinas] = lerNome("Nome da disciplina: ");
        cargas[qtdDisciplinas] = lerInteiro("Carga horária (20 a 200 aulas): ", CARGA_MINIMA, CARGA_MAXIMA);
        qtdDisciplinas++;
        if (salvarDisciplinas()) { System.out.println("Disciplina cadastrada com sucesso!"); }
    }

    // RF02 (VG09)
    static void listarDisciplinas() {
        System.out.println("--- DISCIPLINAS ---");
        if (qtdDisciplinas == 0) {
            System.out.println("Nenhuma disciplina cadastrada.");
            return;
        }
        int soma = 0;
        for (int j = 0; j < qtdDisciplinas; j++) {
            System.out.println(codigos[j] + " | " + nomesDisciplinas[j] + " | " + cargas[j] + " aulas");
            soma += cargas[j];
        }
        System.out.println("Total: " + qtdDisciplinas + " disciplinas, " + soma + " aulas no curso.");
    }

    // RF03 (RN01, RN02, RN05, RN06; VG04)
    static void cadastrarEstudante() {
        System.out.println("--- CADASTRAR ESTUDANTE ---");
        if (qtdEstudantes >= MAX_ESTUDANTES) {
            System.out.println("ERRO: limite de " + MAX_ESTUDANTES + " estudantes atingido.");
            return;
        }
        int ra = lerInteiro("RA (10000 a 99999): ", RA_MINIMO, RA_MAXIMO);
        if (buscarIndiceEstudante(ra) != -1) {
            System.out.println("ERRO: já existe um estudante com o RA " + ra + ".");
            return;
        }
        ras[qtdEstudantes] = ra;
        nomes[qtdEstudantes] = lerNome("Nome completo: ");
        situacoes[qtdEstudantes] = MATRICULADO;
        inicializarDesempenho(qtdEstudantes);
        qtdEstudantes++;
        if (salvarEstudantes()) { System.out.println("Estudante cadastrado com sucesso! Situação: Matriculado."); }
    }

    // RF04 (RN02, RN09)
    static void alterarNomeEstudante() {
        System.out.println("--- ALTERAR NOME DO ESTUDANTE ---");
        int i = pedirEstudante();
        if (i == -1) { return; }
        String antigo = nomes[i];
        String novoNome = lerNome("Nome atual: " + antigo + "\nNovo nome: ");
        if (nomeEstudanteExiste(novoNome, i)) {
            System.out.println("ERRO: já existe outro estudante com esse nome. Nome não alterado.");
            return;
        }
        nomes[i] = novoNome;
        if (salvarEstudantes()) { System.out.println("Nome alterado de \"" + antigo + "\" para \"" + nomes[i] + "\"."); }
    }

    // RF05 (RN09, RN13): notas e faltas continuam guardadas
    static void alterarMatricula() {
        System.out.println("--- TRANCAR OU REATIVAR MATRÍCULA ---");
        int i = pedirEstudante();
        if (i == -1) { return; }
        System.out.println(nomes[i] + " - situação atual: " + nomeSituacao(situacoes[i]));
        String acao = "o TRANCAMENTO";
        if (situacoes[i] == TRANCADO) { acao = "a REATIVAÇÃO"; }
        if (!confirmar("Confirma " + acao + " da matrícula")) {
            System.out.println("Operação cancelada.");
            return;
        }
        situacoes[i] = (situacoes[i] == MATRICULADO) ? TRANCADO : MATRICULADO;
        if (salvarEstudantes()) { System.out.println("Matrícula atualizada: " + nomeSituacao(situacoes[i]) + "."); }
    }

    // RF06 (VG09)
    static void listarEstudantes() {
        System.out.println("--- ESTUDANTES ---");
        if (qtdEstudantes == 0) {
            System.out.println("Nenhum estudante cadastrado.");
            return;
        }
        int trancados = 0;
        for (int i = 0; i < qtdEstudantes; i++) {
            System.out.println(ras[i] + " | " + nomes[i] + " | " + nomeSituacao(situacoes[i]));
            if (situacoes[i] == TRANCADO) { trancados++; }
        }
        System.out.println("Matriculados: " + (qtdEstudantes - trancados) + " | Trancados: " + trancados);
    }

    // conta aprovadas, reprovadas e pendentes do estudante i: {aprovadas, reprovadas, pendentes}
    static int[] contarSituacoes(int i) {
        int[] c = new int[3];
        for (int j = 0; j < qtdDisciplinas; j++) {
            String s = situacaoDisciplina(i, j);
            if (s.equals("APROVADO")) { c[0]++; }
            else if (s.equals("PENDENTE")) { c[2]++; }
            else { c[1]++; }
        }
        return c;
    }

    static String resumoAcademico(int i) {
        int[] c = contarSituacoes(i);
        String geral = texto(calcularMediaGeral(i));
        if (geral.equals("--")) { geral = "sem notas"; }
        return "Média geral: " + geral + " | Aprovadas: " + c[0] + " | Reprovadas: " + c[1] + " | Pendentes: " + c[2];
    }

    // RF07 (RN10, RN12, RN15; VG06)
    static void consultarEstudante() {
        System.out.println("--- CONSULTAR ESTUDANTE ---");
        int i = pedirEstudante();
        if (i == -1) { return; }
        System.out.println("RA: " + ras[i] + " | Nome: " + nomes[i] + " | Situação: " + nomeSituacao(situacoes[i]));
        System.out.println(resumoAcademico(i));
    }

    // RF08 (RN07, RN09, RN10): P1 e P2 lançadas juntas
    static void lancarNotas() {
        System.out.println("--- LANÇAR NOTAS ---");
        int i = pedirEstudanteParaLancamento();
        if (i == -1) { return; }
        System.out.println("Estudante: " + nomes[i]);
        int j = pedirDisciplina();
        if (j == -1) { return; }
        if (notasP1[i][j] >= 0 || notasP2[i][j] >= 0) {
            System.out.println("Notas atuais: P1 " + texto(notasP1[i][j]) + " | P2 " + texto(notasP2[i][j]));
            if (!confirmar("Já existem notas lançadas. Substituir")) {
                System.out.println("Operação cancelada, notas mantidas.");
                return;
            }
        }
        notasP1[i][j] = lerDecimal("Nota da P1 (0 a 10): ", 0, 10);
        notasP2[i][j] = lerDecimal("Nota da P2 (0 a 10): ", 0, 10);
        if (salvarDesempenho()) { System.out.println("Notas lançadas! Média final: " + texto(calcularMedia(i, j))); }
    }

    // RF09 (RN08, RN09, RN11): o valor novo substitui o antigo
    static void lancarFaltas() {
        System.out.println("--- LANÇAR FALTAS ---");
        int i = pedirEstudanteParaLancamento();
        if (i == -1) { return; }
        System.out.println("Estudante: " + nomes[i]);
        int j = pedirDisciplina();
        if (j == -1) { return; }
        System.out.println("Carga horária: " + cargas[j] + " aulas");
        faltas[i][j] = lerInteiro("Total de faltas (0 a " + cargas[j] + "): ", 0, cargas[j]);
        if (salvarDesempenho()) {
            System.out.println("Faltas lançadas! Frequência: " + String.format("%.1f", calcularFrequencia(i, j)) + "%");
            if (calcularFrequencia(i, j) < FREQUENCIA_MINIMA) {
                System.out.println("*** ALERTA: frequência abaixo do mínimo de 75%. ***");
            }
        }
    }

    // monta o boletim (linha i das matrizes); usado na tela (RF10) e no arquivo (RF14)
    static String montarBoletim(int i) {
        String quebra = System.lineSeparator();
        StringBuilder b = new StringBuilder();
        b.append("RA: ").append(ras[i]).append(" - ").append(nomes[i]).append(" (")
                .append(nomeSituacao(situacoes[i])).append(")").append(quebra);
        b.append(String.format("%-24s | %4s | %4s | %6s | %6s | %8s | %s", 
                "Disciplina", "P1", "P2", "Média", "Faltas", "Freq.(%)", "Situação")).append(quebra);
        b.append("-".repeat(91)).append(quebra);
        for (int j = 0; j < qtdDisciplinas; j++) {
            String nomeDisciplina = nomesDisciplinas[j].length() > 24
                    ? nomesDisciplinas[j].substring(0, 24) : nomesDisciplinas[j];
            b.append(String.format("%-24s | %4s | %4s | %6s | %6d | %8s | %s",
                    nomeDisciplina, texto(notasP1[i][j]), texto(notasP2[i][j]),
                    texto(calcularMedia(i, j)), faltas[i][j],
                    String.format("%.1f", calcularFrequencia(i, j)), situacaoDisciplina(i, j)))
                    .append(quebra);
        }
        b.append(resumoAcademico(i));
        return b.toString();
    }

    // RF10 (RN10, RN11, RN12, RN15, VG06): estudante trancado também tem boletim
    static void emitirBoletim() {
        System.out.println("--- BOLETIM DO ESTUDANTE ---");
        int i = pedirEstudante();
        if (i == -1) { return; }
        if (qtdDisciplinas == 0) {
            System.out.println("Nenhuma disciplina cadastrada.");
            return;
        }
        System.out.println(montarBoletim(i));
    }

    // RF11 (RN10 a RN13): percorre a coluna j, só estudantes matriculados
    static void relatorioPorDisciplina() {
        System.out.println("--- DESEMPENHO DA TURMA ---");
        int j = pedirDisciplina();
        if (j == -1) { return; }
        System.out.println("Disciplina: " + nomesDisciplinas[j] + " (" + cargas[j] + " aulas)");
        double soma = 0, maior = -1, menor = 11;
        int comNota = 0, matriculados = 0, aprovados = 0, reprovados = 0, pendentes = 0, iMaior = 0, iMenor = 0;
        for (int i = 0; i < qtdEstudantes; i++) {
            if (situacoes[i] != MATRICULADO) { continue; }
            matriculados++;
            double media = calcularMedia(i, j);
            String sit = situacaoDisciplina(i, j);
            System.out.println(ras[i] + " | " + nomes[i] + " | " + texto(media) + " | "
                    + String.format("%.1f", calcularFrequencia(i, j)) + "% | " + sit);
            if (sit.equals("APROVADO")) { aprovados++; }
            else if (sit.equals("PENDENTE")) { pendentes++; }
            else { reprovados++; }
            if (media >= 0) {
                soma += media;
                comNota++;
                if (media > maior) { maior = media; iMaior = i; }
                if (media < menor) { menor = media; iMenor = i; }
            }
        }
        if (matriculados == 0) {
            System.out.println("Nenhum estudante matriculado.");
        } else if (comNota == 0) {
            System.out.println("Nenhuma nota lançada nesta disciplina.");
        } else {
            System.out.println("Média da turma: " + texto(soma / comNota));
            System.out.println("Maior média: " + texto(maior) + " (" + nomes[iMaior] + ") | Menor média: " + texto(menor) + " (" + nomes[iMenor] + ")");
            System.out.println("Aprovados: " + aprovados + " | Reprovados: " + reprovados + " | Pendentes: " + pendentes);
        }
    }

    // RF12 (RN13, RN15)
    static void relatorioMediaGeral() {
        System.out.println("--- MÉDIA GERAL POR ESTUDANTE ---");
        double soma = 0, melhor = -1;
        int comNota = 0, iMelhor = 0, matriculados = 0;
        for (int i = 0; i < qtdEstudantes; i++) {
            if (situacoes[i] != MATRICULADO) { continue; }
            matriculados++;
            double geral = calcularMediaGeral(i);
            String txt = texto(geral);
            if (geral < 0) { txt = "sem notas"; }
            System.out.println(ras[i] + " | " + nomes[i] + " | média geral: " + txt + " | aprovadas: " + contarSituacoes(i)[0]);
            if (geral >= 0) {
                soma += geral;
                comNota++;
                if (geral > melhor) { melhor = geral; iMelhor = i; }
            }
        }
        if (matriculados == 0) {
            System.out.println("Nenhum estudante matriculado.");
        } else if (comNota == 0) {
            System.out.println("Nenhum estudante possui notas lançadas.");
        } else {
            System.out.println("Média geral da turma: " + texto(soma / comNota));
            System.out.println("Melhor desempenho: " + nomes[iMelhor] + " (RA " + ras[iMelhor] + ") com " + texto(melhor));
        }
    }

    // RF13 (RN11, RN13, RN16)
    static void relatorioRisco() {
        System.out.println("--- ESTUDANTES EM SITUAÇÃO DE RISCO ---");
        int total = 0;
        for (int i = 0; i < qtdEstudantes; i++) {
            if (situacoes[i] != MATRICULADO) { continue; }
            String detalhes = "";
            for (int j = 0; j < qtdDisciplinas; j++) {
                String motivo = "";
                if (calcularMedia(i, j) >= 0 && calcularMedia(i, j) < MEDIA_MINIMA) { motivo = "média " + texto(calcularMedia(i, j)); }
                if (calcularFrequencia(i, j) < FREQUENCIA_MINIMA) {
                    if (!motivo.isEmpty()) { motivo += "; "; }
                    motivo += "frequência " + String.format("%.1f", calcularFrequencia(i, j)) + "%";
                }
                if (!motivo.isEmpty()) { detalhes += "    " + nomesDisciplinas[j] + ": " + motivo + "\n"; }
            }
            if (!detalhes.isEmpty()) {
                total++;
                System.out.print(ras[i] + " - " + nomes[i] + "\n" + detalhes);
            }
        }
        if (total == 0) { System.out.println("Nenhum estudante em situação de risco."); }
        else { System.out.println("Total de estudantes em risco: " + total); }
    }

    // RF14 (RN10 a RN12, RN15, RN17; VG06): grava boletim_<RA>.txt
    static void exportarBoletim() {
        System.out.println("--- EXPORTAR BOLETIM ---");
        int i = pedirEstudante();
        if (i == -1) { return; }
        if (qtdDisciplinas == 0) {
            System.out.println("Nenhuma disciplina cadastrada. Boletim não exportado.");
            return;
        }
        String arquivo = "boletim_" + ras[i] + ".txt";
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(arquivo))) {
            bw.write("INSTITUTO QUALIFICA MAIS - BOLETIM ESCOLAR");
            bw.newLine();
            bw.write("Curso: Qualificação em Assistente Administrativo");
            bw.newLine();
            bw.write(montarBoletim(i));
            bw.newLine();
            System.out.println("Boletim exportado para " + arquivo + ".");
        } catch (IOException e) {
            System.out.println("ATENÇÃO: não foi possível gravar " + arquivo + " (" + e.getMessage() + ").");
        }
    }

    // ---------- carga dos arquivos: RF15 (RN06, RN18, RN19; VG11, VG12) ----------
    // ordem: disciplinas -> estudantes -> desempenho. Linha com problema é ignorada com aviso.

    static void carregarDados() {
        System.out.println("=== CARREGANDO DADOS ===");
        carregarDisciplinas();
        carregarEstudantes();
        carregarDesempenho();
    }

    static void avisarLinha(String arquivo, int linha, String motivo) {
        System.out.println(arquivo + ": linha " + linha + " ignorada - " + motivo);
    }

    // Conta registros não vazios restantes quando a capacidade máxima é atingida.
    static int contarLinhasRestantes(BufferedReader br) throws IOException {
        int total = 0;
        String restante;
        while ((restante = br.readLine()) != null) {
            if (!restante.trim().isEmpty()) { total++; }
        }
        return total;
    }

    // disciplinas.txt -> CODIGO;NOME;CARGA_HORARIA
    static int carregarDisciplinas() {
        int carregados = 0, ignoradas = 0, n = 1;
        try (BufferedReader br = new BufferedReader(new FileReader(ARQ_DISCIPLINAS))) {
            br.readLine(); // cabeçalho
            String linha;
            while ((linha = br.readLine()) != null) {
                n++;
                if (linha.trim().isEmpty()) { continue; }
                if (qtdDisciplinas >= MAX_DISCIPLINAS) {
                    int fora = 1 + contarLinhasRestantes(br);
                    System.out.println(ARQ_DISCIPLINAS + ": carga interrompida por capacidade máxima. " + fora + " linha(s) ficaram de fora.");
                    break;
                }
                String erro = "";
                try {
                    String[] p = linha.split(";");
                    if (p.length != 3) { erro = "esperados 3 campos, vieram " + p.length; }
                    else {
                        int cod = Integer.parseInt(p[0].trim());
                        String nome = p[1].trim();
                        int carga = Integer.parseInt(p[2].trim());
                        if (qtdDisciplinas >= MAX_DISCIPLINAS) { erro = "limite de disciplinas atingido"; }
                        else if (cod < CODIGO_MINIMO || cod > CODIGO_MAXIMO) { erro = "código fora da faixa"; }
                        else if (buscarIndiceDisciplina(cod) != -1) { erro = "código repetido"; }
                        else if (!nomeValido(nome)) { erro = "nome obrigatório"; }
                        else if (carga < CARGA_MINIMA || carga > CARGA_MAXIMA) { erro = "carga horária fora da faixa"; }
                        else {
                            codigos[qtdDisciplinas] = cod;
                            nomesDisciplinas[qtdDisciplinas] = nome;
                            cargas[qtdDisciplinas] = carga;
                            qtdDisciplinas++;
                        }
                    }
                } catch (NumberFormatException e) {
                    erro = "número inválido";
                }
                if (erro.isEmpty()) { carregados++; }
                else { avisarLinha(ARQ_DISCIPLINAS, n, erro); ignoradas++; }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Arquivo " + ARQ_DISCIPLINAS + " não encontrado. Iniciando com cadastro vazio.");
            return 0;
        } catch (IOException e) {
            System.out.println("ATENÇÃO: erro ao ler " + ARQ_DISCIPLINAS + " (" + e.getMessage() + ").");
        }
        System.out.println(ARQ_DISCIPLINAS + ": " + carregados + " registro(s) carregado(s), " + ignoradas + " linha(s) ignorada(s)");
        return carregados;
    }

    // estudantes.txt -> RA;NOME;SITUACAO
    static int carregarEstudantes() {
        int carregados = 0, ignoradas = 0, n = 1;
        try (BufferedReader br = new BufferedReader(new FileReader(ARQ_ESTUDANTES))) {
            br.readLine();
            String linha;
            while ((linha = br.readLine()) != null) {
                n++;
                if (linha.trim().isEmpty()) { continue; }
                if (qtdEstudantes >= MAX_ESTUDANTES) {
                    int fora = 1 + contarLinhasRestantes(br);
                    System.out.println(ARQ_ESTUDANTES + ": carga interrompida por capacidade máxima. " + fora + " linha(s) ficaram de fora.");
                    break;
                }
                String erro = "";
                try {
                    String[] p = linha.split(";");
                    if (p.length != 3) { erro = "esperados 3 campos, vieram " + p.length; }
                    else {
                        int ra = Integer.parseInt(p[0].trim());
                        String nome = p[1].trim();
                        int sit = Integer.parseInt(p[2].trim());
                        if (qtdEstudantes >= MAX_ESTUDANTES) { erro = "limite de estudantes atingido"; }
                        else if (ra < RA_MINIMO || ra > RA_MAXIMO) { erro = "RA fora da faixa"; }
                        else if (buscarIndiceEstudante(ra) != -1) { erro = "RA repetido"; }
                        else if (!nomeValido(nome)) { erro = "nome obrigatório"; }
                        else if (nomeEstudanteExiste(nome, -1)) { erro = "nome de estudante repetido"; }
                        else if (sit != MATRICULADO && sit != TRANCADO) { erro = "situação deve ser " + MATRICULADO + " ou " + TRANCADO; }
                        else {
                            ras[qtdEstudantes] = ra;
                            nomes[qtdEstudantes] = nome;
                            situacoes[qtdEstudantes] = sit;
                            inicializarDesempenho(qtdEstudantes);
                            qtdEstudantes++;
                        }
                    }
                } catch (NumberFormatException e) {
                    erro = "número inválido";
                }
                if (erro.isEmpty()) { carregados++; }
                else { avisarLinha(ARQ_ESTUDANTES, n, erro); ignoradas++; }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Arquivo " + ARQ_ESTUDANTES + " não encontrado. Iniciando com cadastro vazio.");
            return 0;
        } catch (IOException e) {
            System.out.println("ATENÇÃO: erro ao ler " + ARQ_ESTUDANTES + " (" + e.getMessage() + ").");
        }
        System.out.println(ARQ_ESTUDANTES + ": " + carregados + " registro(s) carregado(s), " + ignoradas + " linha(s) ignorada(s)");
        return carregados;
    }

    // desempenho.txt -> RA;CODIGO_DISCIPLINA;P1;P2;FALTAS
    // o RA e o código dão a linha i e a coluna j das matrizes (RN19: par repetido, vale o último)
    static int carregarDesempenho() {
        int carregados = 0, ignoradas = 0, n = 1;
        boolean[][] jaLido = new boolean[MAX_ESTUDANTES][MAX_DISCIPLINAS];
        try (BufferedReader br = new BufferedReader(new FileReader(ARQ_DESEMPENHO))) {
            br.readLine();
            String linha;
            while ((linha = br.readLine()) != null) {
                n++;
                if (linha.trim().isEmpty()) { continue; }
                String erro = "";
                try {
                    String[] p = linha.split(";");
                    if (p.length != 5) { erro = "esperados 5 campos, vieram " + p.length; }
                    else {
                        int i = buscarIndiceEstudante(Integer.parseInt(p[0].trim()));
                        int j = buscarIndiceDisciplina(Integer.parseInt(p[1].trim()));
                        double p1 = Double.parseDouble(p[2].trim());
                        double p2 = Double.parseDouble(p[3].trim());
                        int f = Integer.parseInt(p[4].trim());
                        if (i == -1) { erro = "RA não cadastrado"; }
                        else if (j == -1) { erro = "disciplina " + p[1].trim() + " não cadastrada"; }
                        else if ((p1 != -1 && (p1 < 0 || p1 > 10)) || (p2 != -1 && (p2 < 0 || p2 > 10))) { erro = "nota fora da faixa (use -1 ou 0 a 10)"; }
                        else if (f < 0 || f > cargas[j]) { erro = "faltas fora da faixa (0 a " + cargas[j] + ")"; }
                        else {
                            if (jaLido[i][j]) { System.out.println(ARQ_DESEMPENHO + ": linha " + n + " repete o par " + p[0].trim() + "/" + p[1].trim() + ", vale a última."); }
                            jaLido[i][j] = true;
                            notasP1[i][j] = p1;
                            notasP2[i][j] = p2;
                            faltas[i][j] = f;
                        }
                    }
                } catch (NumberFormatException e) {
                    erro = "número inválido";
                }
                if (erro.isEmpty()) { carregados++; }
                else { avisarLinha(ARQ_DESEMPENHO, n, erro); ignoradas++; }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Arquivo " + ARQ_DESEMPENHO + " não encontrado. Nenhuma nota ou falta lançada.");
            return 0;
        } catch (IOException e) {
            System.out.println("ATENÇÃO: erro ao ler " + ARQ_DESEMPENHO + " (" + e.getMessage() + ").");
        }
        System.out.println(ARQ_DESEMPENHO + ": " + carregados + " registro(s) carregado(s), " + ignoradas + " linha(s) ignorada(s)");
        return carregados;
    }

    // ---------- gravação dos arquivos: RF16 (RN17; VG13) ----------
    // números concatenados (não formatados) para sair com ponto decimal

    static boolean erroGravacao(String arquivo, IOException e) {
        System.out.println("ATENÇÃO: não foi possível gravar o arquivo " + arquivo + " (" + e.getMessage() + "). Os dados permanecem apenas em memória.");
        return false;
    }

    static boolean salvarDisciplinas() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARQ_DISCIPLINAS))) {
            bw.write("CODIGO;NOME;CARGA_HORARIA");
            bw.newLine();
            for (int j = 0; j < qtdDisciplinas; j++) {
                bw.write(codigos[j] + ";" + nomesDisciplinas[j] + ";" + cargas[j]);
                bw.newLine();
            }
            return true;
        } catch (IOException e) {
            return erroGravacao(ARQ_DISCIPLINAS, e);
        }
    }

    static boolean salvarEstudantes() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARQ_ESTUDANTES))) {
            bw.write("RA;NOME;SITUACAO");
            bw.newLine();
            for (int i = 0; i < qtdEstudantes; i++) {
                bw.write(ras[i] + ";" + nomes[i] + ";" + situacoes[i]);
                bw.newLine();
            }
            return true;
        } catch (IOException e) {
            return erroGravacao(ARQ_ESTUDANTES, e);
        }
    }

    // dois laços aninhados: uma linha para cada par estudante x disciplina
    static boolean salvarDesempenho() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARQ_DESEMPENHO))) {
            bw.write("RA;CODIGO_DISCIPLINA;P1;P2;FALTAS");
            bw.newLine();
            for (int i = 0; i < qtdEstudantes; i++) {
                for (int j = 0; j < qtdDisciplinas; j++) {
                    bw.write(ras[i] + ";" + codigos[j] + ";" + notasP1[i][j] + ";" + notasP2[i][j] + ";" + faltas[i][j]);
                    bw.newLine();
                }
            }
            return true;
        } catch (IOException e) {
            return erroGravacao(ARQ_DESEMPENHO, e);
        }
    }

    static void salvarDados() {
        salvarDisciplinas();
        salvarEstudantes();
        salvarDesempenho();
    }
}